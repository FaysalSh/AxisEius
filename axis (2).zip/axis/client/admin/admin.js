
document.addEventListener("DOMContentLoaded", async function() {
    var quill = new Quill('#quillEditor', {
        theme: 'snow',               // Use the 'snow' theme for a simple UI
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline'],  // Text formatting options
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['link', 'image']                          // Link tool
                [{ 'color': [] }]
            ]
        }
    });
    articleCall()
    let authorShow=0;
    document.getElementById('showArticles').addEventListener('click', function() {
        authorShow=0;     
        document.getElementById('articlesTable').style.display = 'table';
        document.getElementById('authorsTable').style.display = 'none';
        articleCall()
    });
    
    document.getElementById('showAuthor').addEventListener('click', function() {
        authorShow=1;
        articleCall()
        document.getElementById('authorsTable').style.display = 'table';
        document.getElementById('articlesTable').style.display = 'none';


    });
   
    async function articleCall(){
    const token = localStorage.getItem('token'); 
    
    if (!token) {
        alert('You are not logged in!');
        window.location.href = 'login.html';
    } else {
            
        try {
            const response = await fetch('http://localhost:3000/api/articles', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const articles = await response.json();   
            
            const authorsTableBody = document.getElementById('authorsTable').querySelector('tbody');
            authorsTableBody.innerHTML = '';
            
            if (authorShow === 1) {
                const uniqueAuthors = new Set();
            
                articles.forEach(article => {
                    if (article.author && article.author.authorName) {
                        uniqueAuthors.add(article.author.authorName);  
                    }
                });
        
                uniqueAuthors.forEach(authorName => {
                    const article = articles.find(article => 
                        article.author && article.author.authorName === authorName
                    );
            
                    if (article && article.author) {
                        const authorRow = document.createElement('tr');
                        authorRow.innerHTML = `
                            <td>${authorName}</td>
                            <td><img src="${article.author.authorImageLink || 'path/to/default-image.jpg'}" alt="Author Image" width="50" height="50"></td>
                            <td>${article.author.authorInfo || 'No Info Available'}</td>
                            <td>
                                ${article.author.authorLink ? 
                                    `<a href="${article.author.authorLink}" target="_blank">${authorName} Link</a>` : 
                                    'No Link Available'}
                            </td>
                        `;
                        authorsTableBody.appendChild(authorRow);
                    }
                });
            }
            
            const articlesTableBody = document.getElementById('articlesTable').querySelector('tbody');
            articlesTableBody.innerHTML = '';
          
            function truncateHtmlContent(content, maxLength) {
                // Create a temporary div to hold the content
                const div = document.createElement('div');
                div.innerHTML = content;
            
                // Convert the content into plain text for truncation
                let text = div.innerText || div.textContent;
                if (text.length > maxLength) {
                    // Truncate the text and append ellipsis
                    text = text.substring(0, maxLength) + '...';
                }

                const truncatedDiv = document.createElement('div');
                truncatedDiv.innerText = text;

                return truncatedDiv.innerHTML;
            }
            articles.forEach(article => {
                
                
                const productTitle = article.product?.title || 'No Title Associated';
                const productImage = article.product?.imageLink || 'No Image Associated';
                const productDescription = article.product?.productDescription || 'No Product Description';
                const author = article.author?.authorName || 'No Author Associated';
                const maxContentLength = 100;
                let truncatedContent = article.content || '';
                truncatedContent = truncateHtmlContent(truncatedContent, maxContentLength);
            
                const articleRow = document.createElement('tr');
                articleRow.innerHTML = `
                    <td>${article.title}</td>
                    <td>${article.description}</td>
                    <td>${truncatedContent}</td>
                    <td>${new Date(article.publishDate).toLocaleDateString()}</td>
                    <td>${author}</td>
                    <td>${article.category}</td>
                    <td>${article.subcategory}</td>
                    <td><img src="${article.imageLink}" alt="Article Image"></td>
                     <td>${article.articleType}</td>
                    <td>${productTitle}</td>
                    <td>
                        ${productImage === 'No Image Associated' 
                            ? 'No Image Associated' 
                            : `<img src="${productImage}" alt="Product Image" onerror="this.src='placeholder.jpg';">`}
                    </td>
                    
                    <td>${productDescription}</td>
                    <td>
                        <button class="edit-button" data-id="${article._id}">Edit</button>
                        <button class="delete-button" data-id="${article._id}">Delete</button>
                    </td>
                `;
                articlesTableBody.appendChild(articleRow);
            });
        
            document.querySelectorAll('.delete-button').forEach(button => {
                button.addEventListener('click', async function() {
                    const articleId = this.getAttribute('data-id');
                    await fetch(`http://localhost:3000/api/articles/${articleId}`, {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    this.parentElement.parentElement.remove();
                });
            });

            document.getElementById('cancelEdit').addEventListener('click', function() {
                document.getElementById('editForm').style.display = 'none';
                document.getElementById('articlesTable').style.display = 'table';
            });

            const subcategories = {
                health: ['Women Health', 'Reproduction and Sexual Health', 'Mental Health', 'Menopause and Aging'],
                fitness: ['Nutrition', 'Fitness', 'Workout'],
                lifestyle: ['Lifestyle and Wellness', 'Relationships', 'Technology and Innovation', 'Hacks', 'Travel', 'Motherhood', 'Family'],
                people: ['Celebrities', 'Influencers', 'Public Figures']
            };
            
            // Function to populate the subcategory dropdown based on the selected category
            function populateSubcategories(category, selectedSubcategory = null) {
                const editsubCategory = document.getElementById('editsubCategory');
                editsubCategory.innerHTML = ''; // Clear existing options
            
                if (subcategories[category]) {
                    subcategories[category].forEach(subcategory => {
                        const option = document.createElement('option');
                        option.value = subcategory.toLowerCase().replace(/\s+/g, '-'); // Format value
                        option.textContent = subcategory;
            
                        // Set the option as selected if it matches the selectedSubcategory
                        if (selectedSubcategory && option.value === selectedSubcategory.toLowerCase().replace(/\s+/g, '-')) {
                            option.selected = true;
                        }
            
                        editsubCategory.appendChild(option);
                    });
                } else {
                    // Handle case where no subcategories exist for the selected category
                    const defaultOption = document.createElement('option');
                    defaultOption.textContent = 'No subcategories available';
                    defaultOption.disabled = true;
                    editsubCategory.appendChild(defaultOption);
                }
            }
            
            // Event listener to update subcategories when the category changes
            document.getElementById('editCategory').addEventListener('change', function () {
                populateSubcategories(this.value);
            });

            document.querySelectorAll('.edit-button').forEach(button => {
                button.addEventListener('click', function () {
                    const articleId = this.getAttribute('data-id');
                    const article = articles.find(a => a._id === articleId);
            
                    // Populate basic article details
                    document.getElementById('articleId').value = articleId;
                    document.getElementById('editTitle').value = article.title;
                    document.getElementById('editDescription').value = article.description;
                    document.getElementById('editTags').value = article.tags.join(', ');
                    document.getElementById('editImageLink').value = article.imageLink;
                    document.getElementById('editCategory').value = article.category;
                    document.getElementById('editArticleType').value = article.articleType;
                    quill.root.innerHTML = article.content || '';
                    const rawDate = article.publishDate;
                    document.getElementById('editPublishDate').value = rawDate
                        ? new Date(rawDate).toISOString().split('T')[0]
                        : '';
            
                    // Populate subcategory dropdown
                         document.getElementById('editCategory').value = article.category;
                        populateSubcategories(article.category, article.subcategory);
            
                  
            
                    // Populate author details
                    const uniqueAuthors = new Map();
                    articles.forEach(article => {
                        const { author } = article;
                        if (author && author.authorName && typeof author.authorName === 'string') {
                            uniqueAuthors.set(author.authorName.toLowerCase(), author);
                        }
                    });
            
                    const authorSelect = document.getElementById('editAuthorSelect');
                    authorSelect.innerHTML = ''; // Clear existing options
            
                    if (article.author && article.author.authorName) {
                        const author = article.author;
                        const option = document.createElement('option');
                        option.value = JSON.stringify(author);
                        option.textContent = author.authorName;
                        option.selected = true;
                        authorSelect.appendChild(option);
                    }
            
                    uniqueAuthors.forEach(author => {
                        const option = document.createElement('option');
                        option.value = JSON.stringify(author);
                        option.textContent = author.authorName;
                        authorSelect.appendChild(option);
                    });
            
                    // Add options for adding or removing authors
                    const addNewOption = document.createElement('option');
                    addNewOption.value = 'addNew';
                    addNewOption.textContent = 'Add New Author';
                    authorSelect.appendChild(addNewOption);
            
                    const noAuthorOption = document.createElement('option');
                    noAuthorOption.value = 'none';
                    noAuthorOption.textContent = 'Remove Author';
                    authorSelect.appendChild(noAuthorOption);
            
                    const unclickableOption = document.createElement('option');
                    unclickableOption.textContent = '--- Select an Option ---';
                    unclickableOption.disabled = true;
                    unclickableOption.selected = true;
                    authorSelect.appendChild(unclickableOption);
            
                    // Handle author selection logic
                    const addNewAuthorFields = document.getElementById('addNewAuthorFields');
                    authorSelect.addEventListener('change', function () {
                        if (this.value === 'addNew') {
                            addNewAuthorFields.style.display = 'block';
                            document.getElementById('editAuthorName').value = '';
                            document.getElementById('editAuthorImageLink').value = '';
                            document.getElementById('editAuthorLink').value = '';
                            document.getElementById('editAuthorInfo').value = '';
                        } else if (this.value === 'none') {
                            addNewAuthorFields.style.display = 'none';
                            document.getElementById('editAuthorName').value = '';
                            document.getElementById('editAuthorImageLink').value = '';
                            document.getElementById('editAuthorLink').value = '';
                            document.getElementById('editAuthorInfo').value = '';
                        } else {
                            addNewAuthorFields.style.display = 'none';
                        }
                    });
            
                    document.getElementById('editForm').style.display = 'block';
                    document.getElementById('articlesTable').style.display = 'none';
                });
            });
            

            document.getElementById('editArticleForm').addEventListener('submit', async function (event) {
                event.preventDefault();
            
                const articleId = document.getElementById('articleId').value;
                const title = document.getElementById('editTitle').value;
                const description = document.getElementById('editDescription').value;
                const content = quill.root.innerHTML;
                const publishDate = document.getElementById('editPublishDate').value;
                const tags = document.getElementById('editTags').value.split(',').map(tag => tag.trim());
                const imageLink = document.getElementById('editImageLink').value;
                const category = document.getElementById('editCategory').value;
            
                // Directly get subcategory value as a string
                const subcategory = document.getElementById('editsubCategory').value;
            
                const articleType = document.getElementById('editArticleType').value;
            
                let author = null;
                const selectedAuthor = document.getElementById('editAuthorSelect').value;
                if (selectedAuthor === 'addNew') {
                    author = {
                        authorName: document.getElementById('editAuthorName').value,
                        authorImageLink: document.getElementById('editAuthorImageLink').value,
                        authorLink: document.getElementById('editAuthorLink').value,
                        authorInfo: document.getElementById('editAuthorInfo').value,
                    };
                } else if (selectedAuthor !== 'none') {
                    try {
                        author = JSON.parse(selectedAuthor); // Safely parse only if needed
                    } catch (err) {
                        console.error('Error parsing selected author:', err);
                    }
                }
            
                // Payload
                const updatedArticle = {
                    title,
                    description,
                    content,
                    publishDate,
                    tags,
                    imageLink,
                    category,
                    subcategory, // Use subcategory as plain string
                    product: {
                        title: document.getElementById('editProductTitle').value,
                        imageLink: document.getElementById('editProductImageLink').value,
                        productDescription: document.getElementById('editProductDescription').value,
                        productLink: document.getElementById('editProductLink').value,
                    },
                    author,
                    articleType,
                };
            
                // PUT request to update article
                try {
                    const response = await fetch(`http://localhost:3000/api/articles/${articleId}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`,
                        },
                        body: JSON.stringify(updatedArticle),
                    });
            
                    if (response.ok) {
                        document.getElementById('editForm').style.display = 'none';
                        document.getElementById('articlesTable').style.display = 'table';
                        window.location.reload();
                    } else {
                        alert('Failed to update article. Please try again.');
                    }
                } catch (error) {
                    console.error('Error updating article:', error);
                    alert('An error occurred while updating the article. Please try again.');
                }
            });
            
            
        } catch (error) {
            console.error(error);
        }
    }
}
});
