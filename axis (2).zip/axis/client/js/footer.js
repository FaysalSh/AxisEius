document.getElementById("footer-container").innerHTML = `
<footer>
 <div class="footer-content">
            <div class="centered-logo">
                <img src="/client/img/logo/ae logo.png" alt="Mini Logo" class="circular-logo">
            </div>
            <div class="footer-links">
                <div class="column">
                    <h4><b>Axis Eius Initiative</b></h4>
                    <ul>
                        <li><a href="/client/about.html">About us</a></li>
                        <li><a href="/client/mission.html">Mission</a></li>
                        <li><a href="/client/vision.html">Vision</a></li>
                        <li><a href="/client/writeWithUs.html#contribute">Contribute</a></li>
                        <li><a href="/client/writeWithUs.html#collaborate">Collaborate</a></li>
                        <!-- <li><a href="/client/writeWithUs.html#write-with-us">Write with us</a></li>
                        <li><a href="/client/contact.html">Contact Us</a></li> -->
                    </ul>
                </div>
                <div class="column">
                    <h4><b>Explore</b></h4>
                    <ul>
                        <li><a href="/client/health&wellness.html">Health + WellBeing</a></li>
                        <li><a href="/client/nutrition&fitness.html">Fitness and Nutrition</a></li>
                        <li><a href="/client/lifestyle.html">Lifestyle</a></li>
                        <li><a href="/client/people.html">People</a></li>
                    </ul>
                </div>
                <div class="column">
                    <h4><b>Resources</b></h4>
                    <ul>
                        <li><a href="/client/Products.html">Products</a></li>
                        <li><a href="/client/writeWithUs.html">Write with us</a></li>
                        <li><a href="/client/contact.html">Contact Us</a></li>
                        
                        <!-- <li><a href="/client/support.html">Support</a></li> -->
                    </ul>
                </div>
            </div>
        </div>
        <p>&copy; 2024 Axis Eius</p>
        </footer>
`;