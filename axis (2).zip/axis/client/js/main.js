
        // search.js
       document.addEventListener('DOMContentLoaded', async function () {
    const searchInput = document.getElementById('searchInput');
    const searchResultsOverlay = document.getElementById('searchResultsOverlay');
    const searchResultsContainer = document.getElementById('searchResults');
    const closeSearchResults = document.getElementById('closeSearchResults');
    const searchIcon = document.querySelector('.search-icon');

    let articles = [];


    async function fetchArticles() {
        try {
            const response = await fetch('http://localhost:3000/api/articles');
            if (!response.ok) {
                throw new Error('Failed to fetch articles');
            }
            articles = await response.json();
        } catch (error) {
            console.error('Error fetching articles:', error);
        }
    }

    await fetchArticles();

    searchInput.addEventListener('input', function () {
        const query = searchInput.value.toLowerCase();
        filterAndDisplayResults(query);
    });

    searchInput.addEventListener('keyup', function (e) {
        if (e.key === 'Enter') {
            const query = searchInput.value.trim().toLowerCase();
            if (query) {
                filterAndDisplayResults(query);
            }
        }
    });

    searchIcon.addEventListener('click', function (e) {
        e.preventDefault();
        searchInput.classList.toggle('active');
        if (searchInput.classList.contains('active')) {
            searchInput.style.display = 'block';
            searchInput.focus();
        } else {
            searchInput.style.display = 'none';
            searchResultsContainer.innerHTML = '';
            searchResultsOverlay.classList.add('hidden');
        }
    });

    closeSearchResults.addEventListener('click', function () {
        searchResultsOverlay.classList.add('hidden');
    });

    // Function to filter and display results
    function filterAndDisplayResults(query) {
        searchResultsContainer.innerHTML = ''; // Clear previous results
        let resultsFound = false;

        articles.forEach(article => {
            const title = article.title.toLowerCase();
            const content = article.content.toLowerCase();
            
            if (title.includes(query) || content.includes(query)) {
                let contentSnippet = article.content;

                if (content.includes(query)) {
                    const startIndex = content.indexOf(query);
                    const endIndex = startIndex + query.length;

                    const contextBefore = 0;
                    const contextAfter = 50; 
                    
                    // Make sure the context is within the bounds of the content
                    const startSnippet = Math.max(startIndex - contextBefore, 0);
                    const endSnippet = Math.min(endIndex + contextAfter, content.length);
                    
                    // Slice the content to show the match with a buffer before and after
                    contentSnippet = content.slice(startSnippet, startIndex) + 
                                     '<span class="highlighted">' + 
                                     content.slice(startIndex, endIndex) + 
                                     '</span>' + 
                                     content.slice(endIndex, endSnippet);
                }
        
                const articleItem = `
                    <a href="articlemodel.html?id=${article._id}">
                        <div class="class-item">
                            <img src="${article.imageLink}" alt="${article.title}"/>
                            <div class="class-text">
                                <h1>${article.title}</h1>
                                <p>${contentSnippet}...</p> <!-- Display snippet of content with match highlighted -->
                            </div>
                        </div>
                    </a>
                `;
                
                searchResultsContainer.innerHTML += articleItem;
                resultsFound = true;
            }
        });
        
        

        if (query && resultsFound) {
            searchResultsOverlay.classList.remove('hidden');
        } else {
            searchResultsOverlay.classList.add('hidden');
        }
    }
});


// document.addEventListener('DOMContentLoaded', function() {
//     const categories = {
//         wellness: {
//             mainImage: {
//                 src: '/client/img/ae picture/pexels-koolshooters-7143283.jpg',
//                 title: 'How To Get Rid of Bumpy Skin',
//                  link: 'single.html'
              
//             },
//             galleryImages: [
//                 {
//                     src: '/client/img/ae picture/pexels-kseniya-budko-58499146-9398506.jpg',
//                     title: '6 Tips for Beach Sunset Pilates',
//                      link: 'single3.html'
                   
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-gabby-k-6620854.jpg',
//                     title: 'Image 2',
                   
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-lina-1841149.jpg',
//                     title: 'Image 3',
                    
//                 }
//             ]
//         },
//         fitness: {
//             mainImage: {
//                 src: '/client/img/ae picture/pexels-marta-wave-6453922.jpg',
//                 title: 'Busting Burnout: How to Spot It, Stop It, and Thrive Again',
//                link: 'single4.html'
                
//             },
//             galleryImages: [
//                 {
//                     src: '/client/img/ae picture/pexels-solodsha-9009969.jpg',
//                     title: 'Healthy Recipe',
//                     link: 'single2.html'
                   
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-gabby-k-6620854.jpg',
//                     title: 'Image 2',
                    
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-lina-1841149.jpg',
//                     title: 'Image 3',
                   
//                 }
//             ]
//         },
//         lifestyle: {
//             mainImage: {
//                 src: '/client/img/ae picture/pexels-173739006-11624012.jpg',
//                 title: 'Main Image',
                
//             },
//             galleryImages: [
//                 {
//                     src: '/client/img/ae picture/pexels-cottonbro-5853820.jpg',
//                     title: 'Wellness Image 1',
                    
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-helloaesthe-26731073.jpg',
//                     title: 'Image 2',
                    
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-solodsha-9009969.jpg',
//                     title: 'Image 3',
                   
//                 }
//             ]
//         },
//         people: {
//             mainImage: {
//                 src: '/client/img/ae picture/pexels-173739006-11624012.jpg',
//                 title: 'Main Image',
                
//             },
//             galleryImages: [
//                 {
//                     src: '/client/img/ae picture/pexels-cottonbro-5853820.jpg',
//                     title: 'Image 1',
               
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-gabby-k-6620854.jpg',
//                     title: 'Image 2',
                    
//                 },
//                 {
//                     src: '/client/img/ae picture/pexels-lina-1841149.jpg',
//                     title: 'Image 3',
                  
//                 }
//             ]
//         }
//     };

//     const categoryButtons = document.querySelectorAll('.category-btn');
//     const mainImage = document.getElementById('mainImage');
//     const mainImageLink = document.getElementById('mainImageLink');
//     const galleryImages = document.querySelectorAll('.image-gallery img');
//     const galleryLinks = document.querySelectorAll('.image-gallery a');
//     const articleTitle = document.getElementById('articleTitle');
    

//     function updateContent(category) {
//         const data = categories[category];
//         setImages(data.mainImage, data.galleryImages);
//         updateText(data.mainImage);
//     }

//     function setImages(mainImg, galleryImgs) {
//         mainImage.src = mainImg.src;
//         mainImage.dataset.index = "0";
//         mainImage.dataset.title = mainImg.title;
//         mainImageLink.href = mainImg.link;
       

//         galleryImages.forEach((img, index) => {
//             img.src = galleryImgs[index].src;
//             img.dataset.index = (index + 1).toString();
//             img.dataset.title = galleryImgs[index].title;
//             galleryLinks[index].href = galleryImgs[index].link;
           
//         });
//     }

//     function swapImages(clickedImg) {
//         const clickedLink = clickedImg.parentElement;
//         const mainSrc = mainImage.src;
//         const mainIndex = mainImage.dataset.index;
//         const mainTitle = mainImage.dataset.title;
//         const mainLink = mainImageLink.href;

//         const clickedSrc = clickedImg.src;
//         const clickedIndex = clickedImg.dataset.index;
//         const clickedTitle = clickedImg.dataset.title;
//         const clickedLinkHref = clickedLink.href;

//         mainImage.src = clickedSrc;
//         mainImage.dataset.index = clickedIndex;
//         mainImage.dataset.title = clickedTitle;
//         mainImageLink.href = clickedLinkHref;

//         clickedImg.src = mainSrc;
//         clickedImg.dataset.index = mainIndex;
//         clickedImg.dataset.title = mainTitle;
//         clickedLink.href = mainLink;

//         updateTitle({title: clickedTitle});
//     }

//     function updateTitle(imageData) {
//         articleTitle.textContent = imageData.title;
//     }

//     galleryImages.forEach(img => {
//         img.addEventListener('click', function(e) {
//             e.preventDefault();
//             swapImages(this);
//         });
//     });

//     categoryButtons.forEach(button => {
//         button.addEventListener('click', function(e) {
//             e.preventDefault();
//             categoryButtons.forEach(btn => btn.classList.remove('active'));
//             this.classList.add('active');
//             const category = this.dataset.category;
//             updateContent(category);
//         });
//     });

//     // Initialize with the first category
//     updateContent('wellness');
// });
// //Jad code

// $(document).ready(function(){
//     var owl = $('.owl-carousel').owlCarousel({
//         items: 3,
//         loop: true,
//         margin: 10,
//         autoplay: true,
//         autoplayTimeout: 3000,
//         autoplayHoverPause: true,
//         onInitialized: updateFirstActiveItem,
//         onTranslated: updateFirstActiveItem
//     });

//     function updateFirstActiveItem(event) {
//         // Remove active-first class from all items
//         $('.owl-item').removeClass('active-first');

//         // Add active-first class to the first active item
//         var $firstActiveItem = $('.owl-item.active').first();
//         $firstActiveItem.addClass('active-first');
        
//         // Logging to debug
//         console.log('First active item updated:', $firstActiveItem.index());
//     }

//     // Initial call to set the class when the carousel is ready
//     updateFirstActiveItem();
// });


/////////////////////////////////
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded and DOM fully parsed');

    const carouselTrack = document.querySelector('.custom-carousel-track');
    const carouselItems = Array.from(carouselTrack.children);
    const prevButton = document.querySelector('.custom-carousel-button.carousel-button-left');
    const nextButton = document.querySelector('.custom-carousel-button.carousel-button-right');
    const itemWidth = carouselItems[0].getBoundingClientRect().width;

    let currentIndex = 0;

    function moveToSlide(track, index) {

        const maxTranslateX = (carouselItems.length - 1) * itemWidth;

 
        if (index < 0) {
            index = 0; 
        } else if (index >= carouselItems.length) {
            index = carouselItems.length - 1; 
        }

        track.style.transform = 'translateX(-' + (index * itemWidth) + 'px)';
    }

    nextButton.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % carouselItems.length;
        moveToSlide(carouselTrack, currentIndex);
    });

    prevButton.addEventListener('click', function() {
        currentIndex = (currentIndex - 1 + carouselItems.length) % carouselItems.length;
        moveToSlide(carouselTrack, currentIndex);
    });

    setInterval(function() {
        currentIndex = (currentIndex + 1) % carouselItems.length;
        moveToSlide(carouselTrack, currentIndex);
    }, 3000);

    moveToSlide(carouselTrack, currentIndex);
});

(function ($) {
    "use strict";
     
    new WOW().init();   
  
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });
    
    
    $(window).scroll(function () {
        if ($(this).scrollTop() > 0) {
            $('.navbar').addClass('nav-sticky');
        } else {
            $('.navbar').removeClass('nav-sticky');
        }
    });
    

    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });
    
   /*ad */



    // Testimonials carousel
    // $(".testimonials-carousel").owlCarousel({
    //     center: true,
    //     autoplay: true,
    //     dots: true,
    //     loop: true,
    //     responsive: {
    //         0:{
    //             items:1
    //         },
    //         576:{
    //             items:1
    //         },
    //         768:{
    //             items:2
    //         },
    //         992:{
    //             items:3
    //         }
    //     }
    // });
    
    
    // Blogs carousel
    
    // $(".blog-carousel").owlCarousel({
    //     autoplay: true,
    //     dots: false,
    //     loop: true,
    //     nav : true,
    //     navText : [
    //         '<i class="fa fa-angle-left" aria-hidden="true"></i>',
    //         '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    //     ],
    //     responsive: {
    //         0:{
    //             items:1
    //         },
    //         576:{
    //             items:1
    //         },
    //         768:{
    //             items:2
    //         },
    //         992:{
    //             items:3
    //         }
    //     }
    // });
    
    /********************* */
    
    // Class filter
    
    var classIsotope = $('.class-container').isotope({
        itemSelector: '.class-item',
        layoutMode: 'fitRows'
    });

    $('#class-filter li').on('click', function () {
        $("#class-filter li").removeClass('filter-active');
        $(this).addClass('filter-active');
        classIsotope.isotope({filter: $(this).data('filter')});
    });
    
    
    // Portfolio filter
    var portfolioIsotope = $('.portfolio-container').isotope({
        itemSelector: '.portfolio-item',
        layoutMode: 'fitRows'
    });

    $('#portfolio-filter li').on('click', function () {
        $("#portfolio-filter li").removeClass('filter-active');
        $(this).addClass('filter-active');
        portfolioIsotope.isotope({filter: $(this).data('filter')});
    });
    
})(jQuery);
 
