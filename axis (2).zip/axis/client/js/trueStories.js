document.addEventListener("DOMContentLoaded", async () => {
    const categoryButtons = document.querySelectorAll(".category-btn");
    const mainImage = document.getElementById("mainImage");
    const mainImageLink = document.getElementById("mainImageLink");
    const articleTitle = document.getElementById("articleTitle");
    const imageGallery = document.getElementById("imageGallery");

    let articles = [];

    try {

        const response = await fetch('http://localhost:3000/api/articles');
        articles = await response.json();

        displayArticles("health");
    } catch (error) {
        console.error("Error fetching articles:", error);
    }

    function displayArticles(category) {

        const filteredArticles = articles.filter(article => article.category.toLowerCase() === category);
        
        if (filteredArticles.length > 0) {

            const featuredArticle = filteredArticles[0];
            mainImage.src = featuredArticle.imageLink || "/client/img/default.jpg";
            mainImageLink.href = `/client/articlemodel.html?id=${featuredArticle._id}`;
            articleTitle.textContent = featuredArticle.title;

            imageGallery.innerHTML = "";
            filteredArticles.slice(1, 4).forEach((article, index) => {
                const galleryHTML = `
                    <a class="gallery-image">
                        <img src="${article.imageLink}" alt="Gallery Image ${index + 1}" data-id="${article._id}" data-title="${article.title}">
                        <div class="read-more">READ MORE</div>
                    </a>
                `;
                imageGallery.insertAdjacentHTML("beforeend", galleryHTML);
            });

document.querySelectorAll(".gallery-image img").forEach(img => {
    img.addEventListener("click", event => {
        event.preventDefault();

        const currentMainImageSrc = mainImage.src;
        const currentMainImageLink = mainImageLink.href;
        const currentMainImageTitle = articleTitle.textContent;

        const clickedImageSrc = img.src;
        const clickedImageId = img.getAttribute("data-id");
        const clickedImageTitle = img.getAttribute("data-title");

        mainImage.classList.add("fade");

        setTimeout(() => {
      
            mainImage.src = clickedImageSrc;
            mainImageLink.href = `/client/articlemodel.html?id=${clickedImageId}`;
            articleTitle.textContent = clickedImageTitle;

            img.src = currentMainImageSrc;
            img.setAttribute("data-id", currentMainImageLink.split('=')[1]);
            img.setAttribute("data-title", currentMainImageTitle);

            mainImage.classList.remove("fade");
        }, 100); 
    });
});

        } else {

            mainImage.src = "/client/img/default.jpg";
            mainImageLink.href = "#";
            articleTitle.textContent = "No articles available in this category.";
            imageGallery.innerHTML = "";
        }
    }

    categoryButtons.forEach(button => {
        button.addEventListener("click", event => {
            event.preventDefault();
            const category = button.getAttribute("data-category");

            categoryButtons.forEach(btn => btn.classList.remove("active"));
            button.classList.add("active");

            displayArticles(category);
        });
    });
});
