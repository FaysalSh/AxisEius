
dynamicImage.onerror = function() {
this.style.display = 'none';
};
// Toggle mobile menu
function toggleMenu() {
const navbar = document.getElementById("navbar");
navbar.className = navbar.className === "" ? "responsive" : "";
}

document.addEventListener("DOMContentLoaded", async function() {
let allArticles = [];
const title=document.getElementById('title')
const navLinks = document.querySelectorAll(".nav-link"); 
try {
const response = await fetch("http://localhost:3000/api/articles");
allArticles = await response.json();

displayArticlesByCategory('featured');
} catch (error) {
console.error("Error fetching articles:", error);
}

// Display articles in sidebar based on selected category
function displayArticlesByCategory(category) {

let filteredArticles

if(category.toLowerCase()==='latest'){                     
filteredArticles = allArticles
.filter(article => article.publishDate) // Ensure publishDate exists
.sort((a, b) => new Date(b.publishDate) - new Date(a.publishDate))
.slice(0, 3);

}else{


filteredArticles = category === 'all'
? allArticles
: allArticles.filter(article => {
const articleCategory = article.articleType ? article.articleType.toLowerCase() : "";
return articleCategory === category.toLowerCase();
});
}
navLinks.forEach(link => {
link.addEventListener("click", function(event) {
event.preventDefault();
navLinks.forEach(nav => nav.classList.remove("active"));
this.classList.add("active");
const category = this.getAttribute("data-category");
displayArticlesByCategory(category);
});
});
const container = document.querySelector(".tab-content");
container.innerHTML = '';

filteredArticles.forEach(article => {

const articleHTML = `
<div class="post-item">
<a href="articlemodel.html?id=${article._id}">
<div class="">
   <img class="imgArticle" src="${article.imageLink}" alt="${article.title}" />
</div>
<div class="post-text">
   <h5>${article.title}</h5>
   <div class="post-meta">    
       <p>In ${article.category || 'General'}</p>
   </div>
 
</div>
</a>
</div>`;
container.innerHTML += articleHTML;
});
}
document.querySelectorAll(".nav-link").forEach(tab => {
tab.addEventListener("click", function(event) {
event.preventDefault();
const category = this.getAttribute("data-category");
displayArticlesByCategory(category);
});
});

displayArticlesByCategory('featured');
function formatDate(dateString) {
const date = new Date(dateString);
const day = date.getDate();
const month = date.toLocaleString('en-US', { month: 'short' });
const year = date.getFullYear();

return `${day}, ${month}, ${year}`;
}
const articleId = new URLSearchParams(window.location.search).get('id');
if (articleId) {
try {
const response = await fetch(`http://localhost:3000/api/articles/${articleId}`);
const article = await response.json();                 
          


const formattedDate = formatDate(article.publishDate);
document.getElementById('articleTitle').innerHTML = `<em>${article.title}</em>`;

document.getElementById('date').innerHTML = `<em>published on: ${formattedDate}</em>`;
document.getElementById('articleImage').src = article.imageLink || 'placeholder.jpg';             
document.getElementById('articleDescription').innerHTML = `<h3>${article.description || 'No description available.'}  </h3> `;
document.getElementById('articleContent').innerHTML  = article.content || 'No content available.';

if (article.product?.title) { 
const productSection = document.getElementById('product');

productSection.style.visibility = "visible";

document.getElementById('productTitle').textContent = article.product.title || 'No Title available.';
document.getElementById('productLink').href = article.product.productLink;
document.getElementById('dynamicImage').src = article.product.imageLink;
document.getElementById('clickable-text').textContent = 'Click on the product image for more details';
}
if (article.author?.authorName) { 
const authorSection = document.getElementById('authorSection');

authorSection.style.display = "block";

document.getElementById('authorName').textContent = article.author.authorName;
document.getElementById('authorLink').href = article.author.authorLink;
document.getElementById('authorImageLink').src = article.author.authorImageLink;
document.getElementById('authorInfo').textContent = article.author.authorInfo;
}

} catch (error) {
console.error('Error fetching article:', error);
}
}
});
