document.getElementById("navbar-container").innerHTML = `
    <nav>
        <ul id="navbar">
            <li><a href="#">Health + Wellness</a>
                <ul>
                    <li><a href="/client/articles.html?subcategory=women-health">Women's Health</a></li>
                    <li><a href="/client/articles.html?subcategory=reproduction-and-sexual-health">Reproductive And Sexual Health</a></li>
                    <li><a href="/client/articles.html?subcategory=mental-health">Mental Health</a></li>
                    <li><a href="/client/articles.html?subcategory=menopause-and-aging">Menopause and Aging</a></li>
                </ul>
            </li>
            <li><a href="#">Fitness + Nutrition</a>
                <ul>
                    <li><a href="/client/articles.html?subcategory=nutrition">Nutrition</a></li>
                    <li><a href="/client/articles.html?subcategory=fitness">Fitness</a></li>
                    <li><a href="/client/articles.html?subcategory=workout">Workout</a></li>
                </ul>
            </li>
            <li><a href="#">Lifestyle</a>
                <ul>
                    <li><a href="/client/articles.html?subcategory=lifestyle-and-wellness">Lifestyle and Wellness</a></li>
                    <li><a href="/client/articles.html?subcategory=relationships">Relationships</a></li>
                    <li><a href="/client/articles.html?subcategory=technology-and-innovation">Technology and Innovation</a></li>
                    <li><a href="/client/articles.html?subcategory=hacks">Hacks</a></li>
                    <li><a href="/client/articles.html?subcategory=travel">Travel</a></li>
                    <li><a href="/client/articles.html?subcategory=motherhood">Motherhood</a></li>
                    <li><a href="/client/articles.html?subcategory=family">Family</a></li>
                </ul>
            </li>
            <li><a href="#">People</a>
                <ul>
                    <li><a href="/client/articles.html?subcategory=celebrities">Celebrities</a></li>
                    <li><a href="/client/articles.html?subcategory=influencers">Influencers</a></li>
                    <li><a href="/client/articles.html?subcategory=public-figures">Public Figures</a></li>
                </ul>
            </li>
            <li class="logo-item"><a href="/client/index.html" class="logo-link">
                    <img src="/client/img/logo/axis logo final.png" alt="Axis Eius Logo" class="rectangular-logo">
                </a></li>
            <li class="keep-touch"><a style="background-color:transparent" href="/client/contact.html" target="_blank">Keep in touch</a></li>
            <li class="search-bar">
                <a href="#" class="search-icon"><img src="/client/img/icons/icons8-search-50.png" alt="Search"></a>
                <input type="text" class="search-input" id="searchInput" placeholder="Search...">
            </li>
        </ul>
        <div class="menu-icon" onclick="toggleMenu()">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>
    <div id="searchResultsOverlay" class="search-overlay hidden">
        <div class="search-results-container">
            <button id="closeSearchResults">×</button>
            <div id="searchResults"></div>
        </div>
    </div>
`;
document.querySelectorAll('#navbar > li > a').forEach(item => {
    const submenu = item.nextElementSibling;

    // Detect if hover capability is available
    const isHoverable = () => window.matchMedia('(hover: hover)').matches;

    // Click to toggle dropdown
    item.addEventListener('click', function (event) {
        if (submenu && submenu.tagName === 'UL') {
            event.preventDefault();
            submenu.classList.toggle('visible');
            this.classList.toggle('arrow-up');
        }
    });

    // Hover for devices that support it
    if (submenu && submenu.tagName === 'UL') {
        const parent = item.parentElement;

        const handleMouseOver = () => {
            if (isHoverable()) submenu.classList.add('visible');
        };

        const handleMouseOut = () => {
            if (isHoverable()) submenu.classList.remove('visible');
        };

        parent.addEventListener('mouseover', handleMouseOver);
        parent.addEventListener('mouseout', handleMouseOut);

        // Re-evaluate hover behavior on resize
        window.addEventListener('resize', () => {
            if (!isHoverable()) {
                submenu.classList.remove('visible');
                item.classList.remove('arrow-up');
            }
        });
    }
});

// Close dropdowns on mobile when clicking elsewhere
document.addEventListener('click', function (event) {
    const target = event.target;
    if (!target.closest('#navbar')) {
        document.querySelectorAll('#navbar > li > ul.visible').forEach(submenu => {
            submenu.classList.remove('visible');
        });
        document.querySelectorAll('#navbar > li > a.arrow-up').forEach(item => {
            item.classList.remove('arrow-up');
        });
    }
});

