
$(document).ready(function () {

const rodinSwiper = document.getElementById("product-swiper-wrapper");

const swiperWrapper = $('.articlesSwiper .swiper-wrapper');

const mostViewedContainer = $('#most-viewed-articles');
mostViewedContainer.html('');
const loadingIndicator = $('<div>').text('Loading articles...').css('text-align', 'center');
 mostViewedContainer.append(loadingIndicator);
swiperWrapper.append(loadingIndicator);

fetch('http://localhost:3000/api/articles')
 .then(response => {
     if (!response.ok) {
         throw new Error(`HTTP error! status: ${response.status}`);
     }
     return response.json();
 })
 .then(articles => {

     const popularArticles = articles.filter(article => article.articleType === 'popular');
     const articleProducts = articles.filter(article => article.product && article.product.imageLink !== '');


    
     
     articleProducts.forEach(articleProduct =>{
   
         const slide = document.createElement("div");
     slide.classList.add("swiper-slide");

     slide.innerHTML = `
         <a href="/client/Products.html?id=${articleProduct._id}">
             <img src="${articleProduct.product.imageLink}" class="favoriteImage" alt="${articleProduct.product.title}">
         </a>
     `;
     
     rodinSwiper.appendChild(slide);
 });

 new Swiper('.rodinSwiper', {
 slidesPerView: 'auto',
 spaceBetween: 30,
 loop: true,
 centeredSlides: false,
 autoplay: {
     delay: 3000,
     disableOnInteraction: false,
 },
 navigation: {
     nextEl: ".rodinSwiper .swiper-button-next",
     prevEl: ".rodinSwiper .swiper-button-prev",
 },
 breakpoints: {
     320: {
         slidesPerView: 1,
         spaceBetween: 10
     },
     480: {
         slidesPerView: 2,
         spaceBetween: 20
     },
     640: {
         slidesPerView: 3,
         spaceBetween: 30
     }
 }
});



     if (popularArticles.length === 0) {
         mostViewedContainer.append('<div style="text-align: center;">No popular articles found.</div>');
         
     }else{
     popularArticles.forEach(article => {
        
         const articleItem = `
             <a href="articlemodel.html?id=${article._id}">
                 <div class="testimonial-item">
                     <div class="testimonial-img">
                         <img src="${article.imageLink}" style="width:250px; height:170px;" alt="${article.title}">
                     </div>
                     <div class="testimonial-text">
                         <h2>${article.title}</h2>
                        <h3>${article.category}</h3>
                       <h3>${article.description}</h3>
                       
                     </div>
                 </div>
             </a>`;
             mostViewedContainer.append(articleItem);
     });

   
 $('#most-viewed-articles').owlCarousel({
 loop: true,
 margin: 30,
 nav: true,
 autoplay: true,
 autoplayTimeout: 3000,
 responsive: {
     0: { items: 1 },       // 1 item on small screens
     576: { items: 1 },     // 1 item on medium screens
     768: { items: 2 },     // 2 items on larger screens
     992: { items: 3 }      // 3 items on large screens
 }
});
}
     articles.forEach(article => {
         if (!article.imageLink || !article.category || !article.title) {
             console.error('Invalid article data:', article);
             return;
         }
         const cleanedSubcategory = article.subcategory ? article.subcategory.replace(/-/g, ' ').trim() : '';

         const slide = $('<div>').addClass('swiper-slide').html(`
             <a href="articlemodel.html?id=${article._id}">
                 <div class="blog-img">
                     <img src="${article.imageLink}" alt="Blog">
                 </div>
                 <div class="blog-text">
                     <p class="category">${cleanedSubcategory}</p>
                     <p>${article.title}</p>
                 </div>
             </a>
         `);
         swiperWrapper.append(slide);
    

     loadingIndicator.remove();

     // Initialize Swiper for dynamic content
     var articlesSwiper = new Swiper('.articlesSwiper', {
slidesPerView: 'auto',
spaceBetween: 30,
loop: true,
centeredSlides: false,
autoplay: {
 delay: 3000,
 disableOnInteraction: false,
},
navigation: {
 nextEl: '.articlesSwiper .swiper-button-next',
 prevEl: '.articlesSwiper .swiper-button-prev',
},
breakpoints: {
 320: {
     slidesPerView: 1,
     spaceBetween: 10
 },
 480: {
     slidesPerView: 2,
     spaceBetween: 20
 },
 640: {
     slidesPerView: 3,
     spaceBetween: 15
 }
}
});
 })


});
})   




 $(document).ready(function () {
     $('#class-filter li').on('click', function () {
         var filterValue = $(this).data('filter');

         // Remove active class from all filter items and add to clicked item
         $('#class-filter li').removeClass('filter-active');
         $(this).addClass('filter-active');

         // Show all items if filterValue is '*', otherwise filter by data-filter value
         if (filterValue === '*') {
             $('.class-item').show();
         } else {
             $('.class-item').hide();
             $(filterValue).show();
         }
     });
 });



