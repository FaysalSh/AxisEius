const mongoose = require('mongoose');

const ArticleSchema = new mongoose.Schema({
    title: String,
    description: String,
    content: String,
    publishDate: Date,
    tags: [String],
    imageLink: String,
    category: String,
    subcategory: String,
    product: {
        title: String,
        imageLink: String,
        productDescription: String,
        productLink: String,
    },
    author: {
        authorName: String,
        authorImageLink: String,
        authorLink: String,
        authorInfo: String,
    },
    articleType: String,
});

module.exports = mongoose.model('Article', ArticleSchema);
