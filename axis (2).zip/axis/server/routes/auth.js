const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const router = express.Router();
const ms = require('ms');

const JWT_EXPIRATION = '60d';

router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body; 
    
        const user = await Admin.findOne({ username });
        
        if (!user) {
          return res.status(404).json({
            message: "User not found",
            success: false,
          });
        }
    
        const isPasswordValid = await bcrypt.compare(password, user.password);
    
        if (isPasswordValid) {
          const token = jwt.sign(
            { username: user.username }, 
            process.env.JWT_SECRET, 
            { expiresIn: JWT_EXPIRATION } 
          );
    
          res.cookie('jwtToken', token, {
            httpOnly: false,
            secure: false,
            sameSite: 'strict',
            maxAge: ms(JWT_EXPIRATION),
          });
    
          return res.status(200).json({
            message: "User Logged In",
            success: true,
            token: token,
            data: { username: user.username }, 
          });
        } else {
          return res.status(401).json({
            message: "Invalid credentials",
            success: false,
          });
        }
      } catch (error) {
        console.error(`Login error: ${error.message}`);
        return res.status(500).json({
          message: `Error: ${error.message}`,
          success: false,
        });
      }
});
router.post('/register', async (req, res) => {
  try {
      const { username, password } = req.body; 

      // Check if the username already exists
      const existingUser = await Admin.findOne({ username });
      if (existingUser) {
          return res.status(400).json({
              message: "Username already taken",
              success: false,
          });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      const newAdmin = new Admin({
          username:username,
          password: hashedPassword,
      });


      await newAdmin.save();

      const token = jwt.sign(
          { username: newAdmin.username },
          process.env.JWT_SECRET,
          { expiresIn: JWT_EXPIRATION }
      );

 
      return res.status(201).json({
          message: "Admin user created successfully",
          success: true,
          token: token,
          data: { username: newAdmin.username },
      });
  } catch (error) {
      console.error(`Registration error: ${error.message}`);
      return res.status(500).json({
          message: `Error: ${error.message}`,
          success: false,
      });
  }
});
module.exports = router;
