const express = require('express');
const path = require('path');
const authenticateJWT = require('../middleware/authenticateJWT');
const router = express.Router();

router.get('/', (req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));
router.get('/admin', authenticateJWT, (req, res) => res.sendFile(path.join(__dirname, '../public/admin.html')));
router.get('/article_submission_form', (req, res) => res.sendFile(path.join(__dirname, '../public/article_submission_form.html')));
router.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../public/login.html')));

module.exports = router;
