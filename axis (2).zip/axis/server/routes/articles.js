const express = require('express');
const Article = require('../models/Article');
const authenticateJWT = require('../middleware/authenticateJWT');
const router = express.Router();

// CREATE - Add a new article
router.post('/', authenticateJWT, async (req, res) => {
    try {
        console.log('Received POST request:', req.body);

        const {
            title,
            description,
            content,
            publishDate,
            tags,
            imageLink,
            category,
            subcategory,
            product,
            author,
            articleType,
        } = req.body;

        // Required fields
        const requiredFields = {
            title,
            description,
            content,
            publishDate,
            tags,
            category,
            subcategory,
            articleType,
        };

        // Identify missing fields
        const missingFields = Object.keys(requiredFields).filter(
            (field) => !requiredFields[field]
        );

        if (missingFields.length > 0) {
            console.error('Validation error: Missing required fields:', missingFields);
            return res.status(400).json({
                message: 'Validation error: Missing required fields',
                missingFields,
            });
        }

        // Build the article data object
        const newArticleData = {
            title,
            description,
            content,
            publishDate,
            tags,
            imageLink,
            category,
            subcategory,
            articleType,
        };

        // Add product information if provided
        if (product) {
            const requiredProductFields = ['title', 'imageLink', 'productDescription', 'productLink'];
            const missingProductFields = requiredProductFields.filter(
                (field) => !product[field]
            );

            if (missingProductFields.length > 0) {
                console.error('Validation error: Missing product fields:', missingProductFields);
                return res.status(400).json({
                    message: 'Validation error: Missing product fields',
                    missingFields: missingProductFields,
                });
            }

            newArticleData.product = {
                title: product.title,
                imageLink: product.imageLink,
                productDescription: product.productDescription,
                productLink: product.productLink,
            };
        }

        if (author) {
            const requiredAuthorFields = ['authorName', 'authorImageLink', 'authorInfo', 'authorLink'];
            const missingAuthorFields = requiredAuthorFields.filter(
                (field) => !author[field]
            );

            if (missingAuthorFields.length > 0) {
                console.error('Validation error: Missing author fields:', missingAuthorFields);
                return res.status(400).json({
                    message: 'Validation error: Missing author fields',
                    missingFields: missingAuthorFields,
                });
            }

            newArticleData.author = {
                authorName: author.authorName,
                authorImageLink: author.authorImageLink,
                authorLink: author.authorLink,
                authorInfo: author.authorInfo,
            };
        }

        const newArticle = new Article(newArticleData);
        await newArticle.save();

        console.log('Article created:', newArticle);
        res.status(200).json({
            message: 'Article submitted successfully',
            article: newArticle,
        });
    } catch (error) {
        console.error('Error submitting article:', error);
        res.status(500).json({
            message: 'Internal Server Error',
            error: error.message,
        });
    }
});

router.get('/', async (req, res) => {
    try {
        const articles = await Article.find();
        res.json(articles);
    } catch (error) {
        console.error('Error fetching articles:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const articleId = req.params.id;
        const article = await Article.findById(articleId);
        if (!article) {
            return res.status(404).json({ message: 'Article not found' });
        }
        res.json(article);
    } catch (error) {
        console.error('Error fetching article:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

router.put('/:id', authenticateJWT, async (req, res) => {
    try {
        const articleId = req.params.id;
        const articleData = req.body;

        const updatedArticle = await Article.findByIdAndUpdate(articleId, articleData, {
            new: true, 
            runValidators: true 
        });

        if (!updatedArticle) {
            return res.status(404).json({ message: 'Article not found' });
        }

        res.json(updatedArticle);
    } catch (error) {
        console.error('Error updating article:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

router.delete('/:id', authenticateJWT, async (req, res) => {
    const { id } = req.params;
    try {
        const deletedArticle = await Article.findByIdAndDelete(id);
        if (!deletedArticle) {
            return res.status(404).json({ message: 'Article not found' });
        }
        res.status(200).json({ message: 'Article deleted successfully' });
    } catch (error) {
        console.error('Error deleting article:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

module.exports = router;
